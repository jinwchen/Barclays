package com.cim;

public class Row {
	
	private int section1;
	private int section2;
	private int section3;
	private int section4;
	
	public int getSection1() {
		return section1;
	}
	public void setSection1(int section1) {
		this.section1 = section1;
	}
	public int getSection2() {
		return section2;
	}
	public void setSection2(int section2) {
		this.section2 = section2;
	}
	public int getSection3() {
		return section3;
	}
	public void setSection3(int section3) {
		this.section3 = section3;
	}
	public int getSection4() {
		return section4;
	}
	public void setSection4(int section4) {
		this.section4 = section4;
	}
	
	
	
}
