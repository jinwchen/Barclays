package com.cim;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

@Controller
public class WelcomeController {

	// go to welcome page
	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {
		
		model.put("seatRequest", new SeatRequest(10, 5)); 
		
		return "welcome";
	}
	
	//Process the ticket requests
    @RequestMapping(value = "/process", method = RequestMethod.POST)
    public String process(@ModelAttribute("seatRequest")SeatRequest seatRequest, ModelMap model) {
    	
    	RestTemplate restTemplate = new RestTemplate();

		String url = "http://localhost:8080/processrequests";
		List<ProcessedRequest> processedRequestList = (List<ProcessedRequest>) restTemplate.postForObject(url, seatRequest, ArrayList.class);
		
		model.addAttribute("processedRequestList", processedRequestList);
		
    	return "output";
    }

}
