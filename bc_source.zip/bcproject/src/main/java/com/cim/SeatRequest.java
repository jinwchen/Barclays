package com.cim;

import java.util.ArrayList;
import java.util.List;

public class SeatRequest {

	private List<Row> rowList;
	private List<TicketRequest> ticketRequestList;
	
	public SeatRequest(int maxRequest, int maxRow) {
		
		ticketRequestList = new ArrayList<TicketRequest>();
		rowList = new ArrayList<Row>();
		
		for (int i=0; i<maxRequest; i++) {
			ticketRequestList.add(new TicketRequest()); 
		}
		
		for (int i=0; i<maxRow; i++) {
			rowList.add(new Row()); 
		}
	}
	
	public SeatRequest() {

	}
	
	public List<TicketRequest> getTicketRequestList() {
		return ticketRequestList;
	}
	public void setTicketRequestList(List<TicketRequest> ticketRequestList) {
		this.ticketRequestList = ticketRequestList;
	}

	public List<Row> getRowList() {
		return rowList;
	}

	public void setRowList(List<Row> rowList) {
		this.rowList = rowList;
	}

	
}
