package com.cim;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SeatService {
    
    @RequestMapping(value = "/processrequests", method = RequestMethod.POST)
    public List<ProcessedRequest> processRequests(@RequestBody SeatRequest seatRequest) 
    {
    	List<TicketRequest> trList = seatRequest.getTicketRequestList();
    	List<Row> rowList = seatRequest.getRowList();
    	List<ProcessedRequest> prList = new ArrayList<ProcessedRequest>();
    	int totalSeats= getTotalSeats(rowList);
    	
    	for (TicketRequest tr : trList) {
    		
    		if (tr.getName()==null || "".equals(tr.getName().trim())) {
    			continue;
    		}
    		
    		int requestedSeat = tr.getTickets();
    		ProcessedRequest pr = new ProcessedRequest();
    		pr.setName(tr.getName());
    		
    		if (requestedSeat > totalSeats) {
    			pr.setProcessed(true);
    			pr.setError(true);
    			pr.setErrorMsg("Sorry, we can't handle your party.");
    		} else {
        		for (int i=0; i<rowList.size(); i++) {

        			int numSeats;
        			Row row = rowList.get(i);
        			
        			numSeats = row.getSection1();
        			if (numSeats >= requestedSeat) {
        				pr.setProcessed(true);
        				pr.setRow(i+1);
        				pr.setSection(1);
        				row.setSection1(numSeats-requestedSeat);
        				totalSeats = totalSeats - requestedSeat;
        				break;
        			}
        			
        			numSeats = row.getSection2();
        			if (numSeats >= requestedSeat) {
        				pr.setProcessed(true);
        				pr.setRow(i+1);
        				pr.setSection(2);
        				row.setSection2(numSeats-requestedSeat);
        				totalSeats = totalSeats - requestedSeat;
        				break;
        			}
        			
        			numSeats = row.getSection3();
        			if (numSeats >= requestedSeat) {
        				pr.setProcessed(true);
        				pr.setRow(i+1);
        				pr.setSection(3);
        				row.setSection3(numSeats-requestedSeat);
        				totalSeats = totalSeats - requestedSeat;
        				break;
        			}
        			
        			numSeats = row.getSection4();
        			if (numSeats >= requestedSeat) {
        				pr.setProcessed(true);
        				pr.setRow(i+1);
        				pr.setSection(4);
        				row.setSection4(numSeats-requestedSeat);
        				totalSeats = totalSeats - requestedSeat;
        				break;
        			}
        		}
    		}
    		
    		if (!pr.isProcessed()) {
    			pr.setProcessed(true);
    			pr.setError(true);
    			pr.setErrorMsg("Call to split party.");
    		}
    		
    		prList.add(pr);
    		
    	}

        return prList;
    }
    
    private int getTotalSeats(List<Row> rowList) {
    	int totalSeats = 0;
    	
    	for (Row row : rowList) {
    		
    		totalSeats = totalSeats + row.getSection1() + row.getSection2() + row.getSection3() + row.getSection4();
    		
    	}
    	return totalSeats;
    }
    
}
