package com.cimtest;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.cim.Row;
import com.cim.SeatRequest;
import com.cim.SpringBootWebApplication;
import com.cim.TicketRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringBootWebApplication.class)
@SpringBootTest
public class SeatServiceTest {

	private MockMvc mockMvc;
	private SeatRequest seatRequest = new SeatRequest();
	
	@Autowired
    private WebApplicationContext wac;
	
	@Before
	public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
        
        List<Row> rowList = new ArrayList<Row>();
        Row row1 = new Row();
        row1.setSection1(2);
        row1.setSection2(3);
        rowList.add(row1);
        
        Row row2 = new Row();
        row2.setSection1(5);
        rowList.add(row2);
        
        seatRequest.setRowList(rowList);
        
        List<TicketRequest> ticketRequestList = new ArrayList<TicketRequest>();
        TicketRequest tr1 = new TicketRequest();
        tr1.setName("John");
        tr1.setTickets(3);
        ticketRequestList.add(tr1);
        TicketRequest tr2 = new TicketRequest();
        tr2.setName("Emma");
        tr2.setTickets(1);
        ticketRequestList.add(tr2);
        TicketRequest tr3 = new TicketRequest();
        tr3.setName("Eiwendy");
        tr3.setTickets(4);
        ticketRequestList.add(tr3);
        TicketRequest tr4 = new TicketRequest();
        tr4.setName("Mary");
        tr4.setTickets(100);
        ticketRequestList.add(tr4);
        TicketRequest tr5 = new TicketRequest();
        tr5.setName("Larry");
        tr5.setTickets(2);
        ticketRequestList.add(tr5);
        
        seatRequest.setTicketRequestList(ticketRequestList);

	}
	
	@Test
	public void testCreateAdCampaign() throws Exception {

		String requestBody = saveRequestJsonString(seatRequest);

		ResultActions result = mockMvc.perform(MockMvcRequestBuilders.post("/processrequests")
																	 .accept(MediaType.APPLICATION_JSON)
																	 .content(requestBody)
																	 .contentType(MediaType.APPLICATION_JSON)
																	 );

		result.andExpect(MockMvcResultMatchers.status().isOk()).andDo(print());
		result.andExpect(MockMvcResultMatchers.content().contentType("application/json;charset=UTF-8")).andDo(print());
	
	}
	
    private String saveRequestJsonString(SeatRequest seatRequest) { 
    	ObjectMapper mapper = new ObjectMapper();
    	try {
			return mapper.writeValueAsString(seatRequest);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;

    }
	
}
